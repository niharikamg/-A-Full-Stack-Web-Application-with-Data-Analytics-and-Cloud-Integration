# sequelize.config.js
